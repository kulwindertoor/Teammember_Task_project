const outputDivTeam = document.getElementById('output-div-team');
const outputDivAssign = document.getElementById('output-div-assign');

function createNewMember(event){
    event.preventDefault();

    const memberValue = document.querySelector("[name='teammedlem']").value;

    const members = {memberValue};
    console.log(memberValue);
    const memberList = JSON.parse(localStorage.getItem('teammedlem')) || [];
    memberList.push(members);

    window.localStorage.setItem('teammedlem', JSON.stringify(memberList));

    event.target.reset();
    renderMember();
}

function renderMember(){
    const memberList = JSON.parse(localStorage.getItem('teammedlem')) || [];
    outputDivTeam.innerHTML = "";

    for(const member of memberList){
        const testOutput = document.createElement('li');
        testOutput.innerHTML = `${member.memberValue}`;
        outputDivTeam.appendChild(testOutput);  
    }
    
}


function assignTaskToMember(event){
    event.preventDefault();

    const assignementValue = document.querySelector("[name='oppgave']").value;
    const memberList = JSON.parse(localStorage.getItem('teammedlem')) || [];

    let teamMember;
    for(const member of memberList){
        teamMember = member.memberValue;
    }
    console.log(teamMember);
    const assignements = {assignementValue, teamMember};
    const assignementList = JSON.parse(localStorage.getItem('oppgaver')) || [];


    assignementList.push(assignements);

    console.log(assignements);
    window.localStorage.setItem('oppgaver', JSON.stringify(assignementList));

    event.target.reset();
    renderAssignement();
}

function renderAssignement(){
    const assignementList = JSON.parse(localStorage.getItem('oppgaver')) || [];

    outputDivAssign.innerHTML = "";
    for(const assign of assignementList){
        const testOutput = document.createElement('li');
        testOutput.innerHTML = `${assign.assignementValue} : ${assign.teamMember}`;
        outputDivAssign.appendChild(testOutput);
    }
    
}
