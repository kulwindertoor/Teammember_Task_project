<b>Gruppe 30</b>

Medlemmer deltatt:
- Markus Kristiansen
- Kulwinder Singh Toor
- Anna Katarzyna Sitarz
- Furkan Kara
- Petter Wibstad
- Pål Anders Byenstuen

____________________________

- [x] querySelector
- [x] getElementById
- [x] localStorage.setItem
- [x] localStorage.getItem
- [x] onsubmit
- [x] appendChild
- [x] createElement

____________________________

Hva koden gjør:<br>
Vi har en funksjon som henter inn en oppgave skrevet av bruker, og legger denne til i oppgavens egen localStorage. Oppgaven blir så skrevet ut til html-dokumentet fra localStorage.
Vi har en funksjon som gjør tilnærmet det samme som oppgave funksjonen, men bare for teammedlem.

Siste funksjon tar inn to verdier der den ene sjekker om verdien finnes i localStorage for oppgaver, og den andre sjekker det samme for teammedlem. Om en av disse ikke eksisterer i localStorage vil ikke funksjonen gjøre noe mer. Om verdien fra begge inputtene eksisterer i localStorage så vil funksjonen legge disse verdiene inn i et eget localStorage. Deretter vil den skrive ut oppgaven og teammedlemmet som er tildelt oppgaven ut til html-dokumentet.


